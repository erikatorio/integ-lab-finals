import java.rmi.*;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.util.Scanner;
import java.io.*;

public class ProjectLeader {
    private static Scanner in = new Scanner(System.in);
	private static LeaderInterface leader;
	private static Registry reg;    
    
    public static void main(String[] args) throws Exception{
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("                           "+ "Welcome Project Leader!"+ "                           " );
		while (true) {
			leader = new LeaderImplement();
			System.out.println("---------------------------------------------------------------------------");
			System.out.print("\n1) View assigned projects.\n2) Assign members to a project.\n3) Update list of members.\n4) Project status setting.\n5) Upload file.\n6) Exit. \nChoice: ");
			int choice = in.nextInt();
			verifyChoice(choice);
			System.out.println("");
		}	
	}
	public static void verifyChoice(int choice) throws Exception{
		switch(choice) {
			case 1: leader.viewProject(); break;
			case 2: leader.assignMember(); break;
			default: System.out.println("Admin Terminated"); 
				     System.out.println("---------------------------------------------------------------------------");
				     System.exit(0);
		}
	}
}
