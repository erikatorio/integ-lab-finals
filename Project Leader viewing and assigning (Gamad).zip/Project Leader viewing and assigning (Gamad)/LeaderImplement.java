import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.NotBoundException;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;
import java.util.*;

public class LeaderImplement extends UnicastRemoteObject implements LeaderInterface{
	
	public LeaderImplement() throws Exception {
		super();
	}
	public void viewProject() throws Exception{
		BufferedReader br = new BufferedReader(new FileReader("Project Assigned.csv"));
		List<String> list = new ArrayList<String>();
		List<String> members = new ArrayList<String>();
		String[] str;
		String[] member;
		int choice;
		String line = "";
		Scanner kbd = new Scanner(System.in);
		System.out.println("");
		System.out.println("THESE ARE YOUR PROJECTS ASSIGNED TO YOU:");
		System.out.println("---------------------------------------------------------------------------");
		while ((line = br.readLine()) != null) {
			list.add(line);
		}
		for(int i = 0; i < list.size(); i++){
			str = list.get(i).split(",");
			BufferedReader mems = new BufferedReader(new FileReader(str[0]+".csv"));
			while ((line = mems.readLine()) != null) {
				members.add(line);
			}
			System.out.printf("%-40s%-20s", "Project Name: " + str[0], "Project status: " + str[1]);
			System.out.println("");
			System.out.println("Project Members:");
			for(int a = 0; a < members.size(); a++){
				int count = a + 1;
				System.out.println(count + ". " + members.get(a));
			}
			System.out.println("");
			members.clear();
			mems.close();
		}
		br.close();
		do{	
			System.out.println("");
			System.out.println("VIEWING MENU:");
			System.out.println("1. View all of my on going projects.");
			System.out.println("2. View all of my completed projects.");
			System.out.println("3. Exit to Main Menu.");
			System.out.print("Your choice number: ");
			choice = kbd.nextInt();
			System.out.println("");
			switch(choice){
				case 1: 
					for(int i = 0; i < list.size(); i++){
						str = list.get(i).split(",");
						if (str[1].equalsIgnoreCase("On Going")){
							BufferedReader mems = new BufferedReader(new FileReader(str[0]+".csv"));
							while ((line = mems.readLine()) != null) {
								members.add(line);
							}
						System.out.printf("%-40s%-20s", "Project Name: " + str[0], "Project status: " + str[1]);
						System.out.println("");
						System.out.println("Project Members:");
						for(int a = 0; a < members.size(); a++){
							int count = a + 1;
							System.out.println(count + ". " + members.get(a));
						}
						System.out.println("");
						members.clear();
						mems.close();
						}else{}
					}
					break;
				case 2:
					for(int i = 0; i < list.size(); i++){
						str = list.get(i).split(",");
						if (str[1].equalsIgnoreCase("Completed")){
							BufferedReader mems = new BufferedReader(new FileReader(str[0]+".csv"));
							while ((line = mems.readLine()) != null) {
								members.add(line);
							}
						System.out.printf("%-40s%-20s", "Project Name: " + str[0], "Project status: " + str[1]);
						System.out.println("");
						System.out.println("Project Members:");
						for(int a = 0; a < members.size(); a++){
							int count = a + 1;
						System.out.println(count + ". " + members.get(a));
					}
						System.out.println("");
						members.clear();
						mems.close();
						}else{}
					}
					break;		
				case 3:	
			}
			
		}while(choice != 3);						
	}

	public void assignMember() throws Exception{
		System.out.println("\nTHESE ARE YOUR ON GOING PROJECTS: ");
		System.out.println("---------------------------------------------------------------------------");
		BufferedReader br = new BufferedReader(new FileReader("Project Assigned.csv"));
		List<String> list = new ArrayList<String>();
		List<String> ongoingProject = new ArrayList<String>();
		String[] str;
		String project;
		String user = null;
		int choice;
		String line = "";
		Scanner kbd = new Scanner(System.in);
		while ((line = br.readLine()) != null) {
				list.add(line);
			}
		br.close();
		System.out.println("Project Name:");
		for(int i = 0; i < list.size(); i++){
			str = list.get(i).split(",");
				if (str[1].equalsIgnoreCase("On Going")){
					System.out.println(" - " + str[0]);
					ongoingProject.add(str[0]);
				}else{}
			}
		do{
			System.out.print("\nWhat project are you going to assign a member? (Enter \"back\" if you wish to exit): ");
			project = kbd.nextLine();
			if(!(ongoingProject.contains(project))){
				System.out.println("Sorry! The project you entered does not exist. Please try again.\n");
			}else{
				BufferedWriter bw = null;
				FileWriter fw = null;
				PrintWriter pw;
				do{
					try{
						System.out.print("Enter the name of the user that will be assign to the " + project + " project (Enter \"back\" if you wish to exit): ");
						user = kbd.nextLine();
						if(!user.equalsIgnoreCase("back")){
							fw = new FileWriter(project + ".csv", true);
							bw = new BufferedWriter(fw);
							pw = new PrintWriter(bw);
							pw.println(user);
							pw.close();
							bw.close();
							fw.close();
						}else{
						}
					}catch (Exception e) {
						e.printStackTrace();
					} 		
				}while(!user.equalsIgnoreCase("back"));	
			}
		}while(!(list.contains(project)) &&  !project.equalsIgnoreCase("back"));
	}
}
	