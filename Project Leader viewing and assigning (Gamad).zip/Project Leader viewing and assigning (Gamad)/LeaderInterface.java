import java.rmi.Remote;
import java.util.ArrayList;

public interface LeaderInterface extends Remote {
		public void viewProject() throws Exception;
		public void assignMember() throws Exception;
}